import React, { useEffect, useRef } from 'react';

/**
 * HeroOverlay — FLIP Shared Element Transition chuẩn Web Animations API:
 *
 * 1. ZERO-FLICKER HANDOFF:
 *    - Render ngay tại tọa độ A (fromRect đã tính từ thẻ đã phóng to và căn giữa ở Home).
 *    - Thẻ WebGL ẩn cùng lúc ở frame này nên không có bất kỳ khoảng trống hay nhấp nháy nào.
 * 2. PRE-DECODE BITMAP:
 *    - Ảnh được gọi img.decode() trước để GPU sẵn sàng, không giật khựng frame đầu.
 * 3. FLIP ANIMATION:
 *    - Animate khung ảnh thay vì kéo giãn transform, để object-fit luôn giữ đúng tỉ lệ trong suốt chuyến bay.
 *    - Sử dụng animation.finished để đóng handoff mượt mà trong cùng 1 frame rAF.
 */
export default function HeroOverlay({ heroTransition, toRect, phase, onLandDone }) {
  const containerRef = useRef(null);
  const imgRef = useRef(null);
  const fromRectRef = useRef(null);
  const isFlyingRef = useRef(false);

  useEffect(() => {
    if (!heroTransition) {
      fromRectRef.current = null;
      isFlyingRef.current = false;
    }
  }, [heroTransition]);

  const imgSrc = heroTransition?.src || heroTransition?.rawCover;
  const fromRect = heroTransition?.fromRect;

  if (fromRect && !fromRectRef.current) {
    fromRectRef.current = fromRect;
  }
  const fr = fromRectRef.current || fromRect;

  // Tiền decode ảnh
  useEffect(() => {
    if (!imgSrc) return;
    const img = new Image();
    img.src = imgSrc;
    if (img.decode) {
      img.decode().catch(() => {});
    }
  }, [imgSrc]);

  // Kích hoạt chuyến bay bằng Web Animations API
  useEffect(() => {
    if (phase !== 'fly' || !toRect || !containerRef.current || !fr || isFlyingRef.current) return;
    isFlyingRef.current = true;

    const el = containerRef.current;

    const anim = el.animate(
      [
        {
          left: `${fr.left}px`,
          top: `${fr.top}px`,
          width: `${fr.width}px`,
          height: `${fr.height}px`,
          clipPath: 'inset(0% 0% 0% 0% round 16px)',
          boxShadow: '0 20px 50px rgba(0,0,0,0.5)',
        },
        {
          left: `${toRect.left}px`,
          top: `${toRect.top}px`,
          width: `${toRect.width}px`,
          height: `${toRect.height}px`,
          clipPath: 'inset(0% 0% 0% 0% round 2px)',
          boxShadow: '0 0 24px rgba(255,255,255,0.45), 0 0 42px rgba(180,210,255,0.25)',
        }
      ],
      {
        duration: 680,
        easing: 'cubic-bezier(0.22, 1, 0.36, 1)',
        fill: 'forwards',
      }
    );

    anim.finished.then(() => {
      requestAnimationFrame(() => {
        onLandDone?.();
      });
    }).catch(() => {});

  }, [phase, toRect, fr, onLandDone]);

  if (!imgSrc || !fr) return null;

  return (
    <div
      ref={containerRef}
      style={{
        position: 'fixed',
        left: `${fr.left}px`,
        top: `${fr.top}px`,
        width: `${fr.width}px`,
        height: `${fr.height}px`,
        transformOrigin: '0 0',
        zIndex: 9999,
        pointerEvents: 'none',
        willChange: 'left, top, width, height, clip-path',
        overflow: 'hidden',
        borderRadius: '16px',
        boxShadow: '0 20px 50px rgba(0,0,0,0.5)',
      }}
    >
      <img
        ref={imgRef}
        src={imgSrc}
        alt="Shared element hero"
        aria-hidden="true"
        decoding="async"
        style={{
          display: 'block',
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          userSelect: 'none',
          pointerEvents: 'none',
        }}
      />
    </div>
  );
}
