import{a as e,o as t,s as n}from"./index-CguPmtBQ.js";import{t as r}from"./ImageLightbox-DUR4ut-L.js";var i=n(t(),1),a=e(),o={aurora:{style:`streak`,colors:[`#f4efe9`,`#e9c2b8`,`#c2433f`,`#2a1e2a`,`#22395e`,`#6f97c2`,`#e5edf4`],scale:.7,warp:1.4,angle:-.62,gloss:.18,veins:0},ember:{style:`marble`,colors:[`#07090c`,`#16252c`,`#3d5f68`,`#1a1416`,`#a3201a`,`#ef4a2b`,`#ff8a5c`],scale:.62,warp:3.2,angle:-.5,gloss:.55,veins:.6},dusk:{style:`marble`,colors:[`#120c18`,`#3e2850`,`#8f6c9c`,`#2b1a24`,`#b3502f`,`#eab08a`,`#fbe7d2`],scale:.75,warp:3.6,angle:.8,gloss:.5,veins:.5},glacier:{style:`streak`,colors:[`#f7f8fa`,`#d9e2ea`,`#9fb4c7`,`#e8edf2`,`#bccbd8`,`#ffffff`],scale:.7,warp:1.6,angle:.35,gloss:.25,veins:0},verdant:{style:`marble`,colors:[`#070b08`,`#173024`,`#4f7a5a`,`#141812`,`#a7843a`,`#e9cf87`,`#fbf3d6`],scale:.7,warp:3.4,angle:2.1,gloss:.5,veins:.5}};function s(e){let t=e.trim().replace(/^#/,``);t.length===3&&(t=t[0]+t[0]+t[1]+t[1]+t[2]+t[2]);let n=/^[0-9a-f]{6}$/i.test(t)?parseInt(t,16):8421504;return[n>>16&255,n>>8&255,n&255]}function c(e){let t=e>>>0;return()=>{t=t+1831565813>>>0;let e=t;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}}function l(e){let t=2166136261;for(let n=0;n<e.length;n++)t=Math.imul(t^e.charCodeAt(n),16777619);return t>>>0}function u(e){let t=c(e),n=new Uint8Array(512),r=new Float32Array(512),i=[];for(let e=0;e<256;e++)i.push(e);for(let e=255;e>0;e--){let n=Math.floor(t()*(e+1)),r=i[e];i[e]=i[n],i[n]=r}for(let e=0;e<512;e++)n[e]=i[e&255];for(let e=0;e<256;e++){let n=t()*Math.PI*2;r[e*2]=Math.cos(n),r[e*2+1]=Math.sin(n)}let a=(e,t)=>{let i=Math.floor(e),a=Math.floor(t),o=e-i,s=t-a,c=i&255,l=a&255,u=n[c+n[l]]*2,d=n[c+1+n[l]]*2,f=n[c+n[l+1]]*2,p=n[c+1+n[l+1]]*2,m=r[u]*o+r[u+1]*s,h=r[d]*(o-1)+r[d+1]*s,g=r[f]*o+r[f+1]*(s-1),_=r[p]*(o-1)+r[p+1]*(s-1),v=o*o*o*(o*(o*6-15)+10),y=s*s*s*(s*(s*6-15)+10);return m+v*(h-m)+y*(g-m+v*(_-g-h+m))};return(e,t,n)=>{let r=0,i=.5;for(let o=0;o<n;o++){r+=i*a(e,t);let n=1.6*e+1.2*t+7.1;t=-1.2*e+1.6*t+3.3,e=n,i*=.5}return r}}function d(e,t,n,r){let i=Math.max(1,Math.round(e)),a=Math.max(1,Math.round(t)),o=n.colors.length>=2?n.colors:[`#111111`,`#eeeeee`],l=o.map((e,t)=>({t:t/(o.length-1),c:s(e)})),d=n.scale??.7,f=n.warp??3,p=n.gloss??.4,m=n.veins??0,h=n.style===`streak`,g=u(r*977+13),_=c(r+1),v=_()*50,y=_()*50,b=(n.angle??0)+(_()-.5)*.5,x=Math.cos(b),S=Math.sin(b),C=Math.min(i,a),w=Math.ceil(i/2)+3,T=Math.ceil(a/2)+3,E=new Float32Array(w*T),D=new Float32Array(w*T),O=new Float32Array(i*a),k=new Float32Array(i*a),A=new Uint8ClampedArray(i*a*4),j=0,M=e=>{for(let t=0;t<w;t++){let n=((t-1)*2-i/2)/C,r=((e-1)*2-a/2)/C,o=(n*x-r*S)*d,s=(n*S+r*x)*d;h&&(o*=.14,s*=2.2),o+=v,s+=y;let c=g(o,s,3),l=g(o+5.2,s+1.3,3),u=g(o+f*c+1.7,s+f*l+9.2,3),p=g(o+f*c+8.3,s+f*l+2.8,3);E[e*w+t]=g(o+f*u,s+f*p,4),D[e*w+t]=Math.sqrt(c*c+l*l)}},N=()=>{let e=(e,t,n,r)=>(-e+9*t+9*n-r)/16,t=new Float32Array(i*T);for(let n=0;n<T;n++){let r=n*w;for(let a=0;a<i;a++){let o=(a>>1)+1;t[n*i+a]=a&1?e(E[r+o-1],E[r+o],E[r+o+1],E[r+o+2]):E[r+o]}}for(let n=0;n<a;n++){let r=(n>>1)+1;for(let a=0;a<i;a++){O[n*i+a]=n&1?e(t[(r-1)*i+a],t[r*i+a],t[(r+1)*i+a],t[(r+2)*i+a]):t[r*i+a];let o=(a>>1)+1,s=D[r*w+o],c=a&1?(s+D[r*w+o+1])/2:s,l=n&1?a&1?(D[(r+1)*w+o]+D[(r+1)*w+o+1])/2:D[(r+1)*w+o]:c;k[n*i+a]=(c+l)/2}}},P=()=>{let e=[],t=Math.max(1,Math.floor(O.length/4096));for(let n=0;n<O.length;n+=t)e.push(O[n]);e.sort((e,t)=>e-t);let n=e[Math.floor(e.length*.02)],r=1/(e[Math.floor(e.length*.98)]-n||1),o=r*C*.012;for(let e=0;e<a;e++)for(let t=0;t<i;t++){let s=e*i+t,c=(O[s]-n)*r;c=c<0?0:c>1?1:c;let u=1;for(;u<l.length-1&&l[u].t<c;)u++;let d=l[u-1],f=l[u],h=(c-d.t)/(f.t-d.t||1);h=h<0?0:h>1?1:h,h=h*h*(3-2*h);let g=(O[t<i-1?s+1:s]-O[t>0?s-1:s])*o,_=(O[e<a-1?s+i:s]-O[e>0?s-i:s])*o,v=(-g*-.55-_*-.65+.52)/Math.sqrt(g*g+_*_+1),y=(v>0?v:0)**24*p*255,b=1+.035*Math.sin(c*150+k[s]*24),x=m*Math.max(0,1-Math.abs(k[s]-.42)*14)*.6,S=(.82+.28*v)*b*(1-x);A[s*4]=(d.c[0]+(f.c[0]-d.c[0])*h)*S+y,A[s*4+1]=(d.c[1]+(f.c[1]-d.c[1])*h)*S+y,A[s*4+2]=(d.c[2]+(f.c[2]-d.c[2])*h)*S+y,A[s*4+3]=255}};return{width:i,height:a,pixels:A,step:e=>{if(j>=T)return!0;let t=Math.min(T,j+Math.max(1,e));for(;j<t;)M(j++);return j<T?!1:(N(),P(),!0)}}}function f(e,t){return t<=1?0:e/(t-1)*2-1}var p=e=>typeof e==`string`?o[e]:e,m=new Map,h=[],g=!1;function _(){if(g)return;g=!0;let e=()=>{let t=performance.now()+4;for(;h.length&&performance.now()<t;){let e=h[0];if(e.job.step(16)){h.shift();let t=document.createElement(`canvas`);t.width=e.job.width,t.height=e.job.height,t.getContext(`2d`)?.putImageData(new ImageData(e.job.pixels,t.width,t.height),0,0),e.done(t)}}h.length?requestAnimationFrame(e):g=!1};requestAnimationFrame(e)}function v(e,t,n,r,i){let a=JSON.stringify([e,t,n,r]),o=m.get(a);return o||(o=new Promise(a=>{let o=h.length;for(;o>1&&h[o-1].priority>i;)o--;h.splice(o,0,{job:d(n,r,e,t),priority:i,done:a}),_()}),m.set(a,o)),o}function y({art:e,seed:t,w:n,h:r,density:o,priority:s,className:c}){let l=i.useRef(null),[u,d]=i.useState(!1),f=p(e),m=JSON.stringify(f),h=Math.round(n*o),g=Math.round(r*o);return i.useEffect(()=>{let e=!0;return d(!1),v(JSON.parse(m),t,h,g,s).then(t=>{let n=l.current;!e||!n||(n.width=t.width,n.height=t.height,n.getContext(`2d`)?.drawImage(t,0,0),d(!0))}),()=>{e=!1}},[m,t,h,g,s]),(0,a.jsx)(`canvas`,{ref:l,"aria-hidden":`true`,className:c,"data-ready":u||void 0,style:{width:n,height:r,maxWidth:`none`}})}var b=340,x=54,S=272,C=184,w=`M0 56A22 22 0 0 1 22 34L146 34C170 34 172 0 198 0L318 0A22 22 0 0 1 340 22L340 250A22 22 0 0 1 318 272L22 272A22 22 0 0 1 0 250Z`,T=`M0 22A22 22 0 0 1 22 0L118 0C144 0 146 32 172 32L318 32A22 22 0 0 1 340 54L340 176A22 22 0 0 1 318 198L22 198A22 22 0 0 1 0 176Z`,E=4,D=[{name:`Cover — final`,meta:`PNG · 4.8 MB`,art:`ember`},{name:`Moodboard`,meta:`24 images`,art:`dusk`},{name:`Brief.pdf`,meta:`PDF · 1.2 MB`}];function O({label:e=`My Files`,meta:t,tone:n=`light`,art:r=`aurora`,seed:o=3,image:s,files:u=D,action:d=`add`,onAdd:p,onFilesChange:m,menu:h=[],labelPlacement:g=`bottom-left`,open:_,defaultOpen:v=!1,onOpenChange:O,onFileSelect:A,width:j=340,appear:M=!0,appearDelay:N=0,className:P,style:F}){let I=i.useId().replace(/:/g,``),L=i.useRef(null),ee=i.useRef(null),R=i.useRef(null),z=i.useRef(null),B=i.useRef(null),[V,te]=i.useState(u),H=i.useRef(u.map((e,t)=>t)),ne=i.useRef(u.length),[U,re]=i.useState(null),[W,ie]=i.useState(0),[ae,oe]=i.useState(v),G=_??ae,K=i.useCallback(e=>{_===void 0&&oe(e),O?.(e)},[_,O]),[q,J]=i.useState(!1),[se,ce]=i.useState(!M),[le,ue]=i.useState(null);i.useEffect(()=>{let e=L.current?.parentElement||L.current;if(!e)return;let t=new ResizeObserver(e=>{for(let t of e){let e=t.contentRect.width;e>0&&ue(e)}});return t.observe(e),()=>t.disconnect()},[]);let de=Math.min(j,le||j),Y=de/b,X=Math.min(1.5,Math.max(1,typeof window>`u`?1:window.devicePixelRatio||1))*Y;i.useEffect(()=>{if(!M)return;let e=L.current;if(!e||typeof IntersectionObserver>`u`){ce(!0);return}let t=0,n=new IntersectionObserver(e=>{e.some(e=>e.isIntersecting)&&(n.disconnect(),t=window.setTimeout(()=>ce(!0),N))},{threshold:.25});return n.observe(e),()=>{n.disconnect(),window.clearTimeout(t)}},[M,N]),i.useEffect(()=>{let e=L.current;if(!e)return;let t=0,n=0,r=0,i=()=>{t=0,e.style.setProperty(`--gf-px`,n.toFixed(3)),e.style.setProperty(`--gf-py`,r.toFixed(3))},a=a=>{if(a.pointerType===`touch`)return;let o=e.getBoundingClientRect();n=(a.clientX-o.left)/o.width*2-1,r=(a.clientY-o.top)/o.height*2-1,t||=requestAnimationFrame(i)},o=()=>{n=0,r=0,t||=requestAnimationFrame(i)};return e.addEventListener(`pointermove`,a),e.addEventListener(`pointerleave`,o),()=>{e.removeEventListener(`pointermove`,a),e.removeEventListener(`pointerleave`,o),cancelAnimationFrame(t)}},[]),i.useEffect(()=>{ee.current?.toggleAttribute(`inert`,!G)},[G]),i.useEffect(()=>{if(!G&&!q)return;let e=e=>{e.key===`Escape`&&(q?(J(!1),z.current?.focus()):(K(!1),R.current?.focus()))},t=e=>{let t=e.target;q&&!B.current?.contains(t)&&!z.current?.contains(t)&&J(!1),G&&!q&&!L.current?.contains(t)&&K(!1)};return document.addEventListener(`keydown`,e),document.addEventListener(`pointerdown`,t),()=>{document.removeEventListener(`keydown`,e),document.removeEventListener(`pointerdown`,t)}},[G,q,K]),i.useEffect(()=>{q&&B.current?.querySelector(`[role=menuitem]`)?.focus()},[q]);let fe=()=>{let e=p?.(V)||{name:`Untitled `+(V.length+1),meta:`Just now`},t=[...V,e],n=ne.current++;H.current=[...H.current,n],te(t),re(n),ie(e=>e+1),m?.(t)},pe=[{label:G?`Close folder`:`Open folder`,onSelect:()=>K(!G)},...h],me=e=>{let t=Array.from(B.current?.querySelectorAll(`[role=menuitem]`)??[]),n=t.indexOf(document.activeElement),r=n=>{e.preventDefault(),t[(n+t.length)%t.length]?.focus()};e.key===`ArrowDown`?r(n+1):e.key===`ArrowUp`?r(n-1):e.key===`Home`?r(0):e.key===`End`?r(t.length-1):e.key===`Tab`&&J(!1)},Z=Math.max(0,V.length-E),Q=V.slice(Z),$=V.length,he=t??$+($===1?` item`:` items`);return(0,a.jsxs)(`div`,{ref:L,className:`gf-root`+(P?` `+P:``),"data-tone":n,"data-open":G||void 0,"data-entered":se||void 0,"data-place":g,style:{width:de,height:326*Y,maxWidth:`100%`,...F},children:[(0,a.jsx)(`style`,{children:k}),(0,a.jsx)(`div`,{className:`gf-stage`,style:{transform:`translateY(`+x*Y+`px) scale(`+Y+`)`},children:(0,a.jsxs)(`div`,{className:`gf-tilt`,children:[(0,a.jsx)(`div`,{className:`gf-shadow`,"aria-hidden":`true`}),(0,a.jsxs)(`div`,{className:`gf-back`,style:{clipPath:`path('M0 56A22 22 0 0 1 22 34L146 34C170 34 172 0 198 0L318 0A22 22 0 0 1 340 22L340 250A22 22 0 0 1 318 272L22 272A22 22 0 0 1 0 250Z')`},"aria-hidden":`true`,children:[s?(0,a.jsx)(`img`,{className:`gf-art`,src:s,alt:``,width:364,height:296,draggable:!1}):r===`none`?null:(0,a.jsx)(y,{className:`gf-art`,art:r,seed:o,w:364,h:296,density:X,priority:0}),(0,a.jsx)(`div`,{className:`gf-back-sheen`})]}),(0,a.jsx)(`svg`,{className:`gf-rim gf-back-rim`,viewBox:`0 0 340 272`,"aria-hidden":`true`,children:(0,a.jsx)(`path`,{d:w})}),(0,a.jsxs)(`div`,{className:`gf-front`+(W?` gf-front--bump`:``),style:{clipPath:`path('M0 22A22 22 0 0 1 22 0L118 0C144 0 146 32 172 32L318 32A22 22 0 0 1 340 54L340 176A22 22 0 0 1 318 198L22 198A22 22 0 0 1 0 176Z')`},children:[(0,a.jsx)(`div`,{className:`gf-tint`,"aria-hidden":`true`}),(0,a.jsx)(`div`,{className:`gf-spec`,"aria-hidden":`true`}),(0,a.jsxs)(`svg`,{className:`gf-rim gf-front-rim`,viewBox:`0 0 340 198`,"aria-hidden":`true`,children:[(0,a.jsx)(`defs`,{children:(0,a.jsxs)(`linearGradient`,{id:`gf-rim-`+I,x1:`0`,y1:`0`,x2:`0`,y2:`1`,children:[(0,a.jsx)(`stop`,{offset:`0`,stopColor:`#fff`,stopOpacity:`0.95`}),(0,a.jsx)(`stop`,{offset:`0.35`,stopColor:`#fff`,stopOpacity:`0.35`}),(0,a.jsx)(`stop`,{offset:`1`,stopColor:`#fff`,stopOpacity:`0.12`})]})}),(0,a.jsx)(`path`,{d:T,stroke:`url(#gf-rim-`+I+`)`})]}),(0,a.jsx)(`button`,{ref:R,type:`button`,className:`gf-hit`,"aria-expanded":G,"aria-label":(G?`Close `:`Open `)+e+`, `+$+($===1?` item`:` items`),onClick:()=>{J(!1),K(!G)}}),(0,a.jsxs)(`div`,{className:`gf-label`,children:[(0,a.jsx)(`span`,{className:`gf-title`,children:e}),(0,a.jsx)(`span`,{className:`gf-meta`,children:he},he)]})]},W),(0,a.jsx)(`div`,{ref:ee,className:`gf-files`,role:`list`,"aria-label":e+` contents`,children:Q.map((e,t)=>{let n=H.current[Z+t],r=f(t,Q.length),i=c(l(e.name)+n),o=!!(e.art||e.image),s=(0,a.jsxs)(a.Fragment,{children:[o?e.image?(0,a.jsx)(`img`,{className:`gf-sheet-art`,src:e.image,alt:``,width:S,height:C,draggable:!1}):(0,a.jsx)(y,{className:`gf-sheet-art`,art:e.art,seed:l(e.name)%997,w:S,h:C,density:Math.min(X,1.25),priority:1}):(0,a.jsxs)(`span`,{className:`gf-lines`,"aria-hidden":`true`,children:[(0,a.jsx)(`i`,{style:{width:`86%`}}),(0,a.jsx)(`i`,{style:{width:`92%`}}),(0,a.jsx)(`i`,{style:{width:`64%`}}),(0,a.jsx)(`i`,{style:{width:`88%`}}),(0,a.jsx)(`i`,{style:{width:`42%`}})]}),(0,a.jsxs)(`span`,{className:`gf-sheet-head`,children:[(0,a.jsx)(`span`,{className:`gf-sheet-name`,children:e.name}),e.meta?(0,a.jsx)(`span`,{className:`gf-sheet-meta`,children:e.meta}):null]})]}),u={className:`gf-sheet`+(o?` gf-sheet--art`:``)+(n===U?` gf-sheet--drop`:``),style:{"--gf-slot":r,"--gf-depth":Q.length-1-t,"--gf-jx":((i()-.5)*10).toFixed(2)+`px`,"--gf-jr":((i()-.5)*3.2).toFixed(2)+`deg`,zIndex:t+1},onAnimationEnd:n===U?()=>re(null):void 0};return(0,a.jsx)(`div`,{role:`listitem`,className:`gf-sheet-slot`,children:e.href?(0,a.jsx)(`a`,{...u,href:e.href,onClick:()=>A?.(e,Z+t),children:s}):(0,a.jsx)(`button`,{...u,type:`button`,onClick:()=>A?.(e,Z+t),children:s})},n)})}),d===`none`?null:(0,a.jsx)(`button`,{ref:z,type:`button`,className:`gf-key gf-key--`+d,"aria-label":d===`add`?`Add a file to `+e:`More options for `+e,"aria-haspopup":d===`more`?`menu`:void 0,"aria-expanded":d===`more`?q:void 0,"aria-controls":d===`more`?`gf-menu-`+I:void 0,onClick:()=>d===`add`?fe():J(e=>!e),children:d===`add`?(0,a.jsx)(`svg`,{className:`gf-glyph gf-glyph--plus`,viewBox:`0 0 24 24`,"aria-hidden":`true`,children:(0,a.jsx)(`path`,{d:`M12 4.5v15M4.5 12h15`})},W):(0,a.jsxs)(`svg`,{className:`gf-glyph gf-glyph--more`,viewBox:`0 0 30 12`,"aria-hidden":`true`,children:[(0,a.jsx)(`rect`,{x:`1`,y:`1.5`,width:`8`,height:`9`,rx:`3.4`}),(0,a.jsx)(`rect`,{x:`11`,y:`1.5`,width:`8`,height:`9`,rx:`3.4`}),(0,a.jsx)(`rect`,{x:`21`,y:`1.5`,width:`8`,height:`9`,rx:`3.4`})]})}),d===`more`?(0,a.jsx)(`div`,{ref:B,id:`gf-menu-`+I,role:`menu`,"aria-label":e+` options`,className:`gf-menu`,"data-open":q||void 0,onKeyDown:me,children:pe.map((e,t)=>(0,a.jsx)(`button`,{type:`button`,role:`menuitem`,tabIndex:q?-1:void 0,disabled:!q,className:`gf-menu-item`+(e.danger?` gf-menu-item--danger`:``),onClick:()=>{J(!1),z.current?.focus(),e.onSelect?.()},children:e.label},e.label+t))}):null]})})]})}var k=`
.gf-root {
  --gf-px: 0;
  --gf-py: 0;
  --gf-ease: cubic-bezier(.2, .8, .2, 1);
  --gf-spring: cubic-bezier(.34, 1.36, .5, 1);
  --gf-hinge: -4deg;
  --gf-lift: -26px; /* Các file nhô sẵn một phần đẹp mắt từ đầu */
  --gf-spread: 6px;
  --gf-fan: 1.2deg;
  --gf-stack: 12px;
  --gf-ink: #141416;
  --gf-ink-soft: rgba(20, 20, 22, .55);
  position: relative;
  display: inline-block;
  flex: none;
  vertical-align: top;
  font-family: ui-sans-serif, system-ui, -apple-system, "SF Pro Text", "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -webkit-tap-highlight-color: transparent;
  isolation: isolate;
}
.gf-root[data-tone="dark"] { --gf-ink: #f5f5f7; --gf-ink-soft: rgba(245, 245, 247, .58); }
.gf-root:hover, .gf-root:focus-within { --gf-hinge: -12deg; --gf-lift: -46px; --gf-spread: 16px; --gf-fan: 2.4deg; --gf-stack: 14px; }
.gf-root[data-open] { --gf-hinge: -26deg; --gf-lift: -102px; --gf-spread: 44px; --gf-fan: 5.5deg; --gf-stack: 32px; }

.gf-stage {
  position: absolute;
  left: 0;
  top: 0;
  width: 340px;
  height: 272px;
  transform-origin: 0 0;
}
.gf-tilt {
  position: absolute;
  inset: 0;
  transform: perspective(1400px) rotateX(calc(var(--gf-py) * -3deg)) rotateY(calc(var(--gf-px) * 4deg));
  transition: transform .9s var(--gf-ease);
}

.gf-shadow {
  position: absolute;
  left: 18px;
  right: 18px;
  bottom: -6px;
  height: 60px;
  border-radius: 40px;
  background: rgba(16, 18, 24, .34);
  filter: blur(22px);
  transform: translateX(calc(var(--gf-px) * -8px));
  transition: transform .9s var(--gf-ease), opacity .9s var(--gf-ease);
}
.gf-root[data-tone="dark"] .gf-shadow { background: rgba(0, 0, 0, .62); }

.gf-back {
  position: absolute;
  inset: 0;
  overflow: hidden;
  background: linear-gradient(180deg, #f3f3f4 0%, #e3e3e6 100%);
}
.gf-root[data-tone="dark"] .gf-back { background: linear-gradient(180deg, #2a2a2e 0%, #121214 100%); }
.gf-art {
  position: absolute;
  left: -12px;
  top: -12px;
  max-width: none;
  object-fit: cover;
  transform: translate(calc(var(--gf-px) * -7px), calc(var(--gf-py) * -6px)) scale(1.02);
  transition: transform 1.1s var(--gf-ease), opacity 1.2s var(--gf-ease), filter 1.2s var(--gf-ease);
}
canvas.gf-art { opacity: 0; filter: blur(14px) saturate(.6); }
canvas.gf-art[data-ready] { opacity: 1; filter: none; }
.gf-back-sheen {
  position: absolute;
  inset: 0;
  background:
    linear-gradient(180deg, rgba(255, 255, 255, .22) 0%, rgba(255, 255, 255, 0) 22%),
    radial-gradient(120% 80% at 80% 0%, rgba(255, 255, 255, .16), rgba(255, 255, 255, 0) 60%);
  pointer-events: none;
}

.gf-rim {
  position: absolute;
  left: 0;
  top: 0;
  max-width: none;
  overflow: visible;
  pointer-events: none;
  fill: none;
}
.gf-back-rim { width: 340px; height: 272px; }
.gf-back-rim path { stroke: rgba(255, 255, 255, .45); stroke-width: 1; }
.gf-root[data-tone="dark"] .gf-back-rim path { stroke: rgba(255, 255, 255, .16); }

/* ---- files ---------------------------------------------------------------- */
.gf-files {
  position: absolute;
  inset: 0;
  z-index: 5;
  pointer-events: none;
  clip-path: inset(-400px -400px 10px -400px);
}
.gf-sheet-slot { display: contents; }
.gf-sheet {
  all: unset;
  box-sizing: border-box;
  position: absolute;
  left: 34px;
  top: 96px;
  width: 272px;
  height: 184px;
  border-radius: 16px;
  overflow: hidden;
  cursor: pointer;
  pointer-events: auto;
  background: linear-gradient(180deg, #ffffff 0%, #f2f2f0 100%);
  box-shadow:
    inset 0 1px 0 rgba(255, 255, 255, .9),
    0 0 0 .5px rgba(0, 0, 0, .1),
    0 10px 26px -8px rgba(10, 12, 20, .28);
  transform-origin: 50% 100%;
  transform:
    translate(calc(var(--gf-jx) + var(--gf-slot) * var(--gf-spread)), calc(var(--gf-lift) + var(--gf-depth) * var(--gf-stack) * -1))
    rotate(calc(var(--gf-jr) + var(--gf-slot) * var(--gf-fan)));
  transition:
    transform .75s var(--gf-spring) calc(var(--gf-depth) * 40ms),
    box-shadow .4s var(--gf-ease),
    translate .9s var(--gf-ease),
    opacity .9s var(--gf-ease);
}
.gf-root[data-tone="dark"] .gf-sheet { background: linear-gradient(180deg, #2c2c30 0%, #1c1c1f 100%); box-shadow: inset 0 1px 0 rgba(255, 255, 255, .14), 0 0 0 .5px rgba(255, 255, 255, .08), 0 12px 28px -8px rgba(0, 0, 0, .7); }
.gf-sheet--art { background: #1a1a1d; }
.gf-root[data-open] .gf-sheet:hover,
.gf-root[data-open] .gf-sheet:focus-visible {
  transform:
    translate(calc(var(--gf-jx) + var(--gf-slot) * var(--gf-spread)), calc(var(--gf-lift) + var(--gf-depth) * var(--gf-stack) * -1 - 18px))
    rotate(calc(var(--gf-slot) * var(--gf-fan) * .6));
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .9), 0 0 0 .5px rgba(0, 0, 0, .1), 0 22px 40px -12px rgba(10, 12, 20, .42);
  transition-delay: 0s;
}
.gf-sheet:focus-visible { outline: 2px solid #4c8dff; outline-offset: 2px; }
.gf-sheet-art {
  position: absolute;
  left: 0;
  top: 0;
  width: 272px;
  height: 184px;
  max-width: none;
  object-fit: cover;
  transition: opacity .9s var(--gf-ease), filter .9s var(--gf-ease);
}
canvas.gf-sheet-art { opacity: 0; filter: blur(10px); }
canvas.gf-sheet-art[data-ready] { opacity: 1; filter: none; }
.gf-sheet--art::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: linear-gradient(180deg, rgba(0, 0, 0, .42) 0%, rgba(0, 0, 0, 0) 34%);
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .2);
  pointer-events: none;
}
.gf-sheet-head {
  position: absolute;
  left: 14px;
  right: 14px;
  top: 11px;
  z-index: 1;
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 10px;
  white-space: nowrap;
}
.gf-sheet-name {
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 12.5px;
  font-weight: 560;
  letter-spacing: -.005em;
  color: #18181b;
}
.gf-sheet-meta {
  flex: none;
  font-family: ui-monospace, "SF Mono", SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 10px;
  letter-spacing: .02em;
  color: rgba(24, 24, 27, .5);
}
.gf-root[data-tone="dark"] .gf-sheet-name, .gf-sheet--art .gf-sheet-name { color: #fafafa; }
.gf-root[data-tone="dark"] .gf-sheet-meta, .gf-sheet--art .gf-sheet-meta { color: rgba(250, 250, 250, .66); }
.gf-lines {
  position: absolute;
  left: 14px;
  right: 14px;
  top: 40px;
  display: flex;
  flex-direction: column;
  gap: 9px;
}
.gf-lines i {
  display: block;
  height: 5px;
  border-radius: 3px;
  background: rgba(24, 24, 27, .08);
}
.gf-lines i:first-child { height: 9px; margin-bottom: 4px; background: rgba(24, 24, 27, .14); }
.gf-root[data-tone="dark"] .gf-lines i { background: rgba(255, 255, 255, .08); }
.gf-root[data-tone="dark"] .gf-lines i:first-child { background: rgba(255, 255, 255, .16); }

.gf-sheet--drop { animation: gf-drop .85s var(--gf-ease) both; }
@keyframes gf-drop {
  0% { translate: 0 -190px; rotate: -9deg; opacity: 0; }
  35% { opacity: 1; }
  72% { translate: 0 10px; rotate: 1deg; }
  100% { translate: 0 0; rotate: 0deg; opacity: 1; }
}

/* ---- front glass ----------------------------------------------------------- */
.gf-front {
  position: absolute;
  left: 0;
  top: 74px;
  width: 340px;
  height: 198px;
  z-index: 10;
  -webkit-backdrop-filter: blur(22px) saturate(1.5);
  backdrop-filter: blur(22px) saturate(1.5);
  transform-origin: 50% 100%;
  transform: perspective(760px) rotateX(var(--gf-hinge));
  transition: transform .8s var(--gf-spring), translate 1s var(--gf-ease), opacity 1s var(--gf-ease);
}
.gf-front--bump { animation: gf-bump .7s var(--gf-ease) .38s both; }
@keyframes gf-bump {
  0% { scale: 1; }
  35% { scale: 1.018 .975; }
  70% { scale: .996 1.006; }
  100% { scale: 1; }
}
.gf-tint {
  position: absolute;
  inset: 0;
  background:
    linear-gradient(180deg, rgba(255, 255, 255, .16) 0%, rgba(255, 255, 255, .5) 42%, rgba(252, 252, 252, .93) 100%);
}
.gf-root[data-tone="dark"] .gf-tint {
  background: linear-gradient(180deg, rgba(18, 18, 20, .18) 0%, rgba(14, 14, 16, .62) 46%, rgba(8, 8, 10, .94) 100%);
}
.gf-spec {
  position: absolute;
  inset: 0;
  background: radial-gradient(260px 200px at calc(50% + var(--gf-px) * 46%) calc(30% + var(--gf-py) * 40%), rgba(255, 255, 255, .5), rgba(255, 255, 255, 0) 70%);
  mix-blend-mode: soft-light;
  opacity: .9;
  transition: background-position .6s var(--gf-ease);
  pointer-events: none;
}
.gf-root[data-tone="dark"] .gf-spec { mix-blend-mode: screen; opacity: .16; }
.gf-front-rim { width: 340px; height: 198px; }
.gf-front-rim path { stroke-width: 2.4; transition: stroke-width .3s var(--gf-ease); }
.gf-root[data-tone="dark"] .gf-front-rim { opacity: .55; }

.gf-hit {
  all: unset;
  position: absolute;
  inset: 0;
  z-index: 1;
  cursor: pointer;
}
.gf-hit:focus-visible ~ .gf-label .gf-title { text-decoration: underline; text-decoration-thickness: 1.5px; text-underline-offset: 4px; }
.gf-front:has(.gf-hit:focus-visible) .gf-front-rim path { stroke-width: 5; }

.gf-label {
  position: absolute;
  z-index: 2;
  display: flex;
  flex-direction: column;
  gap: 6px;
  max-width: 240px;
  pointer-events: none;
  color: var(--gf-ink);
}
.gf-root[data-place="bottom-left"] .gf-label { left: 24px; bottom: 26px; }
.gf-root[data-place="top-left"] .gf-label { left: 24px; top: 28px; }
.gf-root[data-place="top-right"] .gf-label { right: 28px; top: 48px; align-items: flex-start; }
.gf-title {
  font-size: 20px;
  font-weight: 600;
  line-height: 1.2;
  letter-spacing: -.015em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.gf-meta {
  font-family: ui-monospace, "SF Mono", SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 13.5px;
  line-height: 1.35;
  letter-spacing: .02em;
  color: var(--gf-ink-soft);
  white-space: pre-line;
  animation: gf-roll .5s var(--gf-ease) both;
}
@keyframes gf-roll {
  from { opacity: 0; translate: 0 7px; filter: blur(3px); }
  to { opacity: 1; translate: 0 0; filter: blur(0); }
}

/* ---- the key: + or ··· ------------------------------------------------------ */
.gf-key {
  all: unset;
  box-sizing: border-box;
  position: absolute;
  right: 22px;
  bottom: 22px;
  z-index: 12;
  width: 58px;
  height: 58px;
  border-radius: 18px;
  display: grid;
  place-items: center;
  cursor: pointer;
  transition: transform .35s var(--gf-spring), box-shadow .35s var(--gf-ease), background .35s var(--gf-ease);
}
.gf-key:hover { transform: translateY(-2px); }
.gf-key:active { transform: translateY(0) scale(.93); transition-duration: .12s; }
.gf-key:focus-visible { outline: 2px solid #4c8dff; outline-offset: 3px; }
.gf-key--add {
  color: #fff;
  background: radial-gradient(120% 90% at 50% 0%, #3a3a3f 0%, #121214 55%, #050506 100%);
  box-shadow:
    inset 0 1px 0 rgba(255, 255, 255, .22),
    inset 0 -3px 8px rgba(0, 0, 0, .7),
    0 0 0 1px rgba(0, 0, 0, .75),
    0 14px 22px -8px rgba(0, 0, 0, .55),
    0 3px 6px -2px rgba(0, 0, 0, .35);
}
.gf-root[data-tone="dark"] .gf-key--add {
  color: #111113;
  background: radial-gradient(120% 90% at 50% 0%, #ffffff 0%, #ececee 55%, #d2d2d6 100%);
  box-shadow: inset 0 1px 0 #fff, inset 0 -3px 8px rgba(0, 0, 0, .14), 0 0 0 1px rgba(0, 0, 0, .4), 0 14px 22px -8px rgba(0, 0, 0, .7);
}
.gf-key--more {
  color: #111113;
  background: linear-gradient(180deg, rgba(255, 255, 255, .92) 0%, rgba(226, 226, 230, .82) 100%);
  -webkit-backdrop-filter: blur(10px);
  backdrop-filter: blur(10px);
  box-shadow:
    inset 0 1px 0 #fff,
    inset 0 -2px 4px rgba(0, 0, 0, .06),
    0 0 0 1px rgba(0, 0, 0, .16),
    0 10px 18px -8px rgba(0, 0, 0, .3);
}
.gf-root[data-tone="dark"] .gf-key--more {
  color: #f5f5f7;
  background: linear-gradient(180deg, rgba(255, 255, 255, .16) 0%, rgba(255, 255, 255, .06) 100%);
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .22), 0 0 0 1px rgba(255, 255, 255, .1), 0 10px 18px -8px rgba(0, 0, 0, .6);
}
.gf-key--more[aria-expanded="true"] { transform: scale(.96); }
.gf-glyph { display: block; max-width: none; fill: none; stroke: currentColor; stroke-linecap: round; }
.gf-glyph--plus { width: 26px; height: 26px; stroke-width: 1.6; animation: gf-turn .6s var(--gf-spring); }
.gf-glyph--more { width: 30px; height: 12px; stroke-width: 1.7; }
@keyframes gf-turn { from { rotate: -90deg; } to { rotate: 0deg; } }

/* ---- menu ------------------------------------------------------------------- */
.gf-menu {
  position: absolute;
  right: 22px;
  bottom: 90px;
  z-index: 20;
  min-width: 176px;
  padding: 6px;
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  background: rgba(252, 252, 253, .72);
  -webkit-backdrop-filter: blur(24px) saturate(1.6);
  backdrop-filter: blur(24px) saturate(1.6);
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .9), 0 0 0 .5px rgba(0, 0, 0, .14), 0 24px 48px -16px rgba(10, 12, 20, .4);
  transform-origin: 100% 100%;
  opacity: 0;
  visibility: hidden;
  transform: translateY(6px) scale(.94);
  transition: opacity .2s var(--gf-ease), transform .32s var(--gf-spring), visibility 0s .32s;
}
.gf-menu[data-open] { opacity: 1; visibility: visible; transform: none; transition-delay: 0s; }
.gf-root[data-tone="dark"] .gf-menu { background: rgba(30, 30, 34, .72); box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1), 0 0 0 .5px rgba(255, 255, 255, .1), 0 24px 48px -16px rgba(0, 0, 0, .8); }
.gf-menu-item {
  all: unset;
  box-sizing: border-box;
  padding: 9px 12px;
  border-radius: 10px;
  font-size: 13.5px;
  font-weight: 450;
  color: #18181b;
  cursor: pointer;
}
.gf-root[data-tone="dark"] .gf-menu-item { color: #f4f4f5; }
.gf-menu-item:hover, .gf-menu-item:focus-visible { background: rgba(24, 24, 27, .07); }
.gf-root[data-tone="dark"] .gf-menu-item:hover, .gf-root[data-tone="dark"] .gf-menu-item:focus-visible { background: rgba(255, 255, 255, .09); }
.gf-menu-item--danger { color: #d92d20; }
.gf-root[data-tone="dark"] .gf-menu-item--danger { color: #ff6b5e; }

/* ---- entrance: the folder assembles itself ---------------------------------- */
.gf-root:not([data-entered]) .gf-back,
.gf-root:not([data-entered]) .gf-back-rim { translate: 0 10px; opacity: 0; }
.gf-root:not([data-entered]) .gf-sheet { translate: 0 -40px; opacity: 0; }
.gf-root:not([data-entered]) .gf-front { translate: 0 20px; opacity: 0; }
.gf-root:not([data-entered]) .gf-key { opacity: 0; scale: .8; }
.gf-root:not([data-entered]) .gf-shadow { opacity: 0; }
.gf-back, .gf-back-rim { transition: translate .4s var(--gf-ease), opacity .4s var(--gf-ease); }
.gf-root[data-entered] .gf-sheet { transition-delay: calc(var(--gf-depth) * 20ms), 0s, calc(.08s + var(--gf-depth) * 40ms), calc(.08s + var(--gf-depth) * 40ms); }
.gf-root[data-entered] .gf-front { transition-delay: 0s, .16s, .16s; }
.gf-key { transition: transform .25s var(--gf-spring), box-shadow .25s var(--gf-ease), opacity .3s var(--gf-ease) .2s, scale .3s var(--gf-spring) .2s; }

@media (prefers-reduced-motion: reduce) {
  .gf-root *, .gf-root *::before, .gf-root *::after {
    transition-duration: 0s !important;
    transition-delay: 0s !important;
    animation: none !important;
  }
  .gf-tilt { transform: none; }
}
`,A=`
  attribute vec4 a_position;
  void main() {
    gl_Position = a_position;
  }
`,j=`
precision mediump float;

uniform vec2 iResolution;
uniform float iTime;

#define TAU 6.28318530718
#define MAX_ITER 5

void mainImage(out vec4 fragColor, in vec2 fragCoord) {
    float time = iTime * 0.5 + 23.0;

    vec2 uv = fragCoord.xy / iResolution.xy;

    vec2 p = mod(uv * TAU, TAU) - 250.0;
    vec2 i = vec2(p);
    float c = 1.0;
    float inten = 0.005;

    for (int n = 0; n < MAX_ITER; n++) {
        float t = time * (1.0 - (3.5 / float(n + 1)));
        i = p + vec2(
            cos(t - i.x) + sin(t + i.y),
            sin(t - i.y) + cos(t + i.x)
        );
        c += 1.0 / length(vec2(
            p.x / (sin(i.x + t) / inten),
            p.y / (cos(i.y + t) / inten)
        ));
    }

    c /= float(MAX_ITER);
    c = 1.17 - pow(c, 1.4);

    vec3 colour = vec3(pow(abs(c), 8.0));
    colour = clamp(colour + vec3(0.0, 0.35, 0.5), 0.0, 1.0);

    fragColor = vec4(colour, 1.0);
}

void main() {
    mainImage(gl_FragColor, gl_FragCoord.xy);
}
`,M={none:`0px`,sm:`4px`,md:`12px`,lg:`16px`,xl:`24px`,"2xl":`40px`,"3xl":`64px`};function N({backdropBlurAmount:e=`sm`,className:t=``,style:n={}}){let r=(0,i.useRef)(null);(0,i.useEffect)(()=>{let e=r.current;if(!e)return;let t=e.getContext(`webgl`);if(!t){console.error(`WebGL not supported`);return}let n=(e,n)=>{let r=t.createShader(e);return r?(t.shaderSource(r,n),t.compileShader(r),t.getShaderParameter(r,t.COMPILE_STATUS)?r:(console.error(`Shader compilation error:`,t.getShaderInfoLog(r)),t.deleteShader(r),null)):null},i=n(t.VERTEX_SHADER,A),a=n(t.FRAGMENT_SHADER,j);if(!i||!a)return;let o=t.createProgram();if(!o)return;if(t.attachShader(o,i),t.attachShader(o,a),t.linkProgram(o),!t.getProgramParameter(o,t.LINK_STATUS)){console.error(`Program linking error:`,t.getProgramInfoLog(o));return}t.useProgram(o);let s=t.createBuffer();t.bindBuffer(t.ARRAY_BUFFER,s),t.bufferData(t.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),t.STATIC_DRAW);let c=t.getAttribLocation(o,`a_position`);t.enableVertexAttribArray(c),t.vertexAttribPointer(c,2,t.FLOAT,!1,0,0);let l=t.getUniformLocation(o,`iResolution`),u=t.getUniformLocation(o,`iTime`),d=0,f=Date.now(),p=()=>{let n=e.clientWidth||300,r=e.clientHeight||200;(e.width!==n||e.height!==r)&&(e.width=n,e.height=r,t.viewport(0,0,n,r));let i=(Date.now()-f)/1e3;t.uniform2f(l,n,r),t.uniform1f(u,i),t.drawArrays(t.TRIANGLES,0,6),d=requestAnimationFrame(p)};return p(),()=>{cancelAnimationFrame(d)}},[]);let o=M[e]||`12px`;return(0,a.jsxs)(`div`,{className:t,style:{position:`relative`,width:`100%`,height:`100%`,overflow:`hidden`,...n},children:[(0,a.jsx)(`canvas`,{ref:r,style:{position:`absolute`,inset:0,width:`100%`,height:`100%`,display:`block`}}),(0,a.jsx)(`div`,{style:{position:`absolute`,inset:0,backdropFilter:`blur(${o})`,WebkitBackdropFilter:`blur(${o})`,pointerEvents:`none`}})]})}var P=[{id:`pkg-chup`,title:`Gói chụp`,subtitle:`Phù hợp với các nhu cầu chụp ảnh cá nhân, đời sống, kỷ niệm và concept đơn giản.`,priceLine:`399.000 🐟 / buổi
Ưu đãi chỉ từ 149.000🐟/h`,image:`https://res.cloudinary.com/g55oyjhn/image/upload/v1790935995/DSC00990.avif`,art:`glacier`,defaultAlbumId:`chan-dung`,pricingDetail:{title:`Bảng Giá & Chi Tiết Dịch Vụ — Chụp Ảnh Cá Nhân / Lifestyle`,tag:`Gói trọn buổi: 399.000🐟/Buổi (~4 tiếng) · Giá theo giờ: Gốc 189.000🐟/h → Ưu đãi 149.000🐟/h`,items:[`Thời gian chụp: 01 buổi chụp thoải mái (~4 tiếng) hoặc book linh hoạt theo giờ.`,`Địa điểm: Quán cafe, công viên, đường phố Sài Gòn theo concept yêu thích.`,`Hỗ trợ bắt khoảnh khắc: Chỉ dẫn tạo dáng theo tính cách Từng Mẫu, Hướng dẫn tạo dáng theo phong cách nhân vật (Cos), tôn nét đẹp riêng của bạn.`,`Bàn giao: Toàn bộ file gốc độ phân giải cao + 15 đến 20 ảnh blend màu chỉnh sửa theo yêu cầu.`,`🎁 CHÍNH SÁCH ƯU ĐÃI THEO GIỜ: Giá tiêu chuẩn 189.000🐟/h. ĐẶC BIỆT: Giảm ngay còn 149.000🐟/h khi khách hàng đồng ý hỗ trợ photo toàn quyền sử dụng hình ảnh buổi chụp để quảng bá trên mạng xã hội & portfolio cá nhân.`],note:`Phù hợp: Tả thực, Chân dung nghệ thuật, Kỷ niệm ngày lễ, Sinh nhật, Couple tình cảm, Ảnh đời thường aesthetic.`},masterText:{headline:`Chân Dung & Đời Sống — Lưu Giữ Những Khoảnh Khắc Nguyên Bản`,lead:`Vẻ đẹp chân thật nhất là vẻ đẹp khi bạn là chính mình: tự do, an nhiên và tràn đầy cảm xúc.`,sections:[{title:`01 / NẮM BẮT KHOẢNH KHẮC THẬT (CANDID MOMENTS)`,content:`Thay vì những tư thế tạo dáng rập khuôn cứng nhắc, chúng tôi tạo không khí trò chuyện gần gũi để bắt trọn những nụ cười bất chợt, ánh mắt dịu dàng và những chuyển động tự nhiên nhất của bạn.`},{title:`02 / CHẤT MÀU PHIM TRẦM ẤM & HOÀI NIỆM`,content:`Tone màu được lấy cảm hứng từ phim nhựa analog: độ hạt grain mịn màng, vùng sáng mềm mại và sắc xanh hoài niệm, tạo cảm giác bền vững cùng thời gian.`},{title:`03 / TRỌN VẸN KỶ NIỆM`,content:`Từng bức ảnh sau buổi chụp là một lát cắt ký ức được nâng niu, sẵn sàng để in album photobook hoặc lưu giữ trong thư viện cá nhân.`}]}},{id:`pkg-theo-yeu-cau`,title:`Gói chụp theo yêu cầu`,subtitle:`Dành cho các yêu cầu chụp ảnh có concept, kế hoạch hoặc quy mô riêng.`,priceLine:`Từ 499.000 🐟`,image:`https://res.cloudinary.com/g55oyjhn/image/upload/v1788545041/Still_2026-09-05_010136_1.3.1.jpg`,art:`aurora`,defaultAlbumId:`ky-yeu`,pricingDetail:{title:`Bảng Giá & Quy Trình — Concept Theo Yêu Cầu`,tag:`Tùy biến dự án · Từ 499.000 🐟`,items:[`Xây dựng Concept riêng: Trao đổi phong cách, bảng màu (color palette), trang phục và đạo cụ phù hợp.`,`Chọn lọc địa điểm & bối cảnh đặc biệt: Studio chuyên nghiệp, ngoại cảnh thiên nhiên, kiến trúc độc đáo.`,`Chăm chút từng khung hình: Đo sáng chính xác, định hình mood & tone theo chuẩn Lookbook quốc tế.`,`Hậu kỳ chuyên sâu: Retouch tỉ mỉ từng chi tiết da (high-end frequency separation), căn chỉnh phom dáng tự nhiên.`],note:`Phù hợp: Thời trang (Fashion Lookbook), Kỷ yếu concept cao cấp, Brand Ambassador, Profile doanh nhân.`},masterText:{headline:`Concept & Nghệ Thuật Tạo Hình — Tuyên Ngôn Cá Tính Độc Bản`,lead:`Mỗi dự án concept là một công trình nghệ thuật thị giác độc lập được may đo riêng cho từng câu chuyện thương hiệu.`,sections:[{title:`01 / TƯ DUY NGHỆ THUẬT & ĐỊNH HƯỚNG CONCEPT`,content:`Từ ý tưởng sơ khai, chúng tôi cùng bạn phát triển moodboard hoàn chỉnh: từ ánh sáng tương phản cao (chiaroscuro), sắc thái avant-garde đến sự tối giản tinh tế của phong cách Scandinavian.`},{title:`02 / KỸ THUẬT RETOUCH CHUYÊN SÂU`,content:`Áp dụng quy trình xử lý da chuyên nghiệp (Dodge & Burn, Frequency Separation), giữ nguyên vân da tự nhiên và làm nổi bật chất liệu vải, trang sức một cách sắc nét nhất.`},{title:`03 / BẢN SẮC KHÁC BIỆT`,content:`Kết quả mang lại không chỉ là bộ ảnh đẹp, mà là một tài sản hình ảnh có giá trị truyền thông và khẳng định vị thế thương hiệu cá nhân của bạn.`}]}},{id:`pkg-video`,title:`Gói quay video`,subtitle:`Phù hợp với quay content, review, cá nhân và các nhu cầu quay đơn giản.`,priceLine:`299.000 🐟 / buổi`,image:`https://res.cloudinary.com/g55oyjhn/image/upload/v1786775685/Tiktok.webp`,art:`ember`,defaultAlbumId:`tiec-bai-bien-cos`,pricingDetail:{title:`Bảng Giá & Chi Tiết Dịch Vụ — Quay Video`,tag:`Gói cơ bản · 299.000 🐟 / buổi`,items:[`Thời gian làm việc: 01 buổi (2 - 3 tiếng) linh hoạt theo địa điểm chỉ định.`,`Thiết bị: Camera chất lượng cao 4K / Full HD, mic thu âm không dây chống ồn.`,`Hỗ trợ trong buổi quay: Tư vấn góc máy, hướng dẫn cử chỉ/tạo dáng, chọn bối cảnh sáng đẹp.`,`Sản phẩm bàn giao: 02 - 04 video ngắn hoàn chỉnh (đã dựng, căn màu, âm thanh cơ bản) hoặc toàn bộ raw footage.`],note:`Phù hợp: Content Creator, Reviewer, Shop Online, TikToker, cá nhân xây kênh.`},masterText:{headline:`Master Storytelling — Video Ngắn Chạm Cảm Xúc`,lead:`Trong kỷ nguyên số, một thước phim 30 giây đủ sức truyền tải trọn vẹn phong cách sống và dấu ấn cá nhân của bạn.`,sections:[{title:`01 / ĐỊNH HƯỚNG TẦNG HÌNH ẢNH (VISUAL IDENTITY)`,content:`Mỗi khung hình không chỉ đơn thuần là ghi hình, mà là sự cân nhắc tỉ mỉ về nguồn sáng, bố cục đường dẫn và nhịp điệu chuyển động. Chúng tôi kết hợp các góc máy cận và trung để làm nổi bật thần thái tự nhiên nhất.`},{title:`02 / XỬ LÝ HẬU KỲ CHUYÊN NGHIỆP`,content:`Quy trình dựng nhịp theo tiết tấu âm thanh, xử lý dynamic zoom tinh tế và phân giải màu cinematic giúp video của bạn nổi bật giữa dòng tin tức mạng xã hội.`},{title:`03 / TỐI ƯU ĐA NỀN TẢNG`,content:`Tỷ lệ khung hình chuẩn 9:16 cho Reels / TikTok / Shorts với bitrate sắc nét, đảm bảo không bị suy giảm chất lượng khi đăng tải.`}]}},{id:`pkg-cinematic`,title:`Gói Cinematic`,subtitle:`Dành cho các sản phẩm video cần lên ý tưởng, quay và hậu kỳ theo yêu cầu.`,priceLine:`Từ 1.899.000 🐟`,image:`https://res.cloudinary.com/g55oyjhn/image/upload/v1790936046/DSC01094.avif`,art:`dusk`,defaultAlbumId:`vincom-mall-cos`,pricingDetail:{title:`Bảng Giá & Quy Trình — Cinematic Project`,tag:`Dự án sản xuất · Từ 1.899.000 🐟`,items:[`Họp ý tưởng & Moodboard: Thảo luận concept, xây dựng kịch bản phân cảnh (storyboard chi tiết).`,`Thiết bị điện ảnh: Ống kính prime/cinema, hệ thống gimbal ổn định, đèn studio setup ánh sáng chuyên sâu.`,`Color Grading chuẩn Hollywood: Phối màu theo tông LUT độc quyền, tách lớp màu da và background.`,`Sound Design & Sound Effects: Phối hợp nhạc nền có bản quyền và hiệu ứng âm thanh môi trường sống động.`],note:`Phù hợp: Fashion film, MV ca nhạc, Video thương hiệu cá nhân, Phim ngắn nghệ thuật, Brand Story.`},masterText:{headline:`Điện Ảnh Hóa Từng Khung Hình — Nghệ Thuật Kể Chuyện Bằng Ánh Sáng`,lead:`Không chỉ là quay phim, đây là sự hòa quyện giữa ngôn ngữ điện ảnh, tâm lý nhân vật và triết lý thẩm mỹ đương đại.`,sections:[{title:`01 / NGÔN NGỮ ĐIỆN ẢNH & NHỊP ĐIỆU CẢM XÚC`,content:`Mỗi chuyển động của máy quay (camera movement) đều mang một ý đồ biểu đạt: những cú tracking tĩnh lặng, tilt-up kiêu hãnh hay góc nghiêng dutch-angle nội tâm. Tất cả phục vụ cho thông điệp cốt lõi của bạn.`},{title:`02 / NGHỆ THUẬT COLOR GRADING ĐA LỚP`,content:`Màu sắc là linh hồn của Cinematic. Chúng tôi sử dụng bảng màu điện ảnh với độ sâu tương phản mềm, giữ trọn sắc thái da tự nhiên và làm nổi bật chiều sâu không gian ba chiều.`},{title:`03 / HOÀN THIỆN ĐẦU RA 4K DCI`,content:`Master xuất file chuẩn DCI 4K HDR, sẵn sàng trình chiếu sự kiện, màn hình lớn cũng như truyền thông cao cấp trên mọi nền tảng kỹ thuật số.`}]}}],F=[{title:`ĐẶT CỌC VÀ THANH TOÁN`,items:[`Khách hàng vui lòng đặt cọc 50% tổng chi phí để giữ lịch. Tiền cọc không hoàn lại nếu bên phía khách hàng tự ý huỷ lịch mà không có lý do bất khả kháng.`,`Toàn bộ phần còn lại sẽ được hoàn thiện thanh toán sau khi bàn giao ảnh.`]},{title:`DỜI LỊCH VÀ HUỶ LỊCH`,items:[`Khách hàng có quyền thay đổi lịch miễn phí 1 lần nếu thông báo trước tối thiểu 7 ngày trước buổi chụp. Lịch mới sẽ phụ thuộc vào thời gian trống của photographer.`,`Trong trường hợp lý do bất khả kháng (thời tiết xấu, sự cố thiên tai/sức khoẻ...), hai bên hỗ trợ dời lịch miễn phí.`]},{title:`TRẢ SẢN PHẨM VÀ CHỈNH SỬA`,items:[`Ảnh gốc sẽ được trả trong vòng 48 giờ kể từ khi kết thúc buổi chụp.`,`Ảnh hoàn thiện sẽ được trả theo lịch hẹn trên gói chụp. Thời gian tính từ lúc khách hàng hoàn thành việc chọn ảnh.`,`Photographer hỗ trợ chỉnh sửa tối đa 3 lần theo Concept/Style ban đầu. Mọi yêu cầu chỉnh sửa quá số lần hoặc thay đổi Concept/Style khác sẽ tính thêm phí.`]},{title:`BẢN QUYỀN VÀ QUYỀN SỬ DỤNG`,items:[`Toàn bộ bản quyền tác giả hình ảnh thuộc về photographer.`,`Khách hàng có quyền tự do sử dụng hình ảnh cho mục đích cá nhân và truyền thông cá nhân.`,`Khách hàng không được cung cấp hình ảnh cho bên thứ ba vì mục đích thương mại khi chưa có sự đồng thuận bằng văn bản từ photographer.`,`Chính sách quyền hình ảnh quảng bá & Ưu đãi giá chụp theo giờ:`,`• Giá tiêu chuẩn (Bảo mật riêng tư): 189.000🐟/h — Áp dụng khi khách hàng muốn giữ bảo mật tuyệt đối, photo không đăng tải hoặc sử dụng hình ảnh buổi chụp lên mạng xã hội.`,`• Giá ưu đãi đồng hành (Giảm còn 149.000🐟/h): Áp dụng khi khách hàng đồng ý hỗ trợ cho phép photo toàn quyền sử dụng hình ảnh đã chụp để đăng tải truyền thông, cập nhật portfolio và quảng bá dịch vụ.`]},{title:`TÁC PHONG & LƯU TRỮ`,items:[`Thời gian chụp tính từ giờ đã hẹn. Nếu khách hàng đến muộn quá 60 phút kể từ thời gian hẹn, photographer có quyền đơn phương huỷ buổi chụp mà không hoàn lại cọc.`,`Toàn bộ file ảnh sẽ được lưu trữ trong 60 ngày kể từ ngày bàn giao sản phẩm hoàn thiện cuối cùng. Sau thời gian này, photographer không chịu trách nhiệm nếu file bị thất lạc.`]}],I=({theme:e=`light`,onCategorySelect:t})=>{let[n,o]=(0,i.useState)(null),[s,c]=(0,i.useState)(null),l=e=>{window.open(`https://zalo.me/0348007036`,`_blank`,`noopener,noreferrer`)},u=e===`dark`?`dark`:`light`,d=(e,t)=>{t===0?c({src:e.image,alt:`${e.title} - Ảnh mẫu`}):o(t===1?{type:`pricing`,product:e}:{type:`master`,product:e})};return(0,a.jsxs)(`div`,{className:`contact-page`,children:[s&&(0,a.jsx)(r,{src:s.src,alt:s.alt,onClose:()=>c(null)}),n&&n.type===`pricing`&&(0,a.jsx)(`div`,{className:`contact-modal-overlay`,onClick:()=>o(null),children:(0,a.jsxs)(`div`,{className:`contact-modal-card contact-modal-card--pricing`,onClick:e=>e.stopPropagation(),children:[(0,a.jsx)(`div`,{className:`contact-subtle-reflect-bg`,"aria-hidden":`true`,children:(0,a.jsx)(N,{backdropBlurAmount:`2xl`})}),(0,a.jsx)(`button`,{className:`contact-modal-close`,onClick:()=>o(null),children:`← ĐÓNG`}),(0,a.jsxs)(`div`,{className:`contact-pricing-modal-body`,children:[(0,a.jsx)(`span`,{className:`contact-pricing-badge`,children:n.product.pricingDetail.tag}),(0,a.jsx)(`h2`,{className:`contact-pricing-title`,children:n.product.pricingDetail.title}),(0,a.jsx)(`ul`,{className:`contact-pricing-list`,children:n.product.pricingDetail.items.map((e,t)=>(0,a.jsxs)(`li`,{className:`contact-pricing-item`,children:[(0,a.jsx)(`span`,{className:`contact-pricing-check`,children:`✓`}),(0,a.jsx)(`span`,{children:e})]},t))}),(0,a.jsxs)(`div`,{className:`contact-pricing-note`,children:[(0,a.jsx)(`strong`,{children:`Ghi chú:`}),` `,n.product.pricingDetail.note]}),(0,a.jsxs)(`div`,{className:`contact-modal-purchase`,style:{marginTop:24},children:[(0,a.jsx)(`span`,{className:`contact-modal-price`,style:{whiteSpace:`pre-line`,lineHeight:1.4},children:n.product.priceLine}),(0,a.jsx)(`button`,{className:`contact-modal-btn`,onClick:()=>l(n.product),children:`TƯ VẤN & BÁO GIÁ ZALO`})]})]})]})}),n&&n.type===`master`&&(0,a.jsx)(`div`,{className:`contact-modal-overlay`,onClick:()=>o(null),children:(0,a.jsxs)(`div`,{className:`contact-modal-card contact-modal-card--master`,onClick:e=>e.stopPropagation(),children:[(0,a.jsx)(`div`,{className:`contact-subtle-reflect-bg contact-subtle-reflect-bg--master`,"aria-hidden":`true`,children:(0,a.jsx)(N,{backdropBlurAmount:`3xl`})}),(0,a.jsx)(`div`,{className:`contact-document-fold`,"aria-hidden":`true`}),(0,a.jsx)(`div`,{className:`contact-document-fold-edge`,"aria-hidden":`true`}),(0,a.jsx)(`button`,{className:`contact-modal-close`,onClick:()=>o(null),children:`← ĐÓNG`}),(0,a.jsxs)(`div`,{className:`contact-master-content-body`,children:[(0,a.jsx)(`div`,{className:`contact-master-badge`,children:`MASTER EDITORIAL & ART DIRECTION`}),(0,a.jsx)(`h1`,{className:`contact-master-headline`,children:n.product.masterText.headline}),(0,a.jsx)(`p`,{className:`contact-master-lead`,children:n.product.masterText.lead}),(0,a.jsx)(`hr`,{className:`contact-master-divider`}),(0,a.jsx)(`div`,{className:`contact-master-sections`,children:n.product.masterText.sections.map((e,t)=>(0,a.jsxs)(`div`,{className:`contact-master-sec-block`,children:[(0,a.jsx)(`h3`,{className:`contact-master-sec-title`,children:e.title}),(0,a.jsx)(`p`,{className:`contact-master-sec-desc`,children:e.content})]},t))}),(0,a.jsx)(`div`,{className:`contact-master-actions`,children:(0,a.jsx)(`button`,{className:`contact-modal-btn`,onClick:()=>l(n.product),children:`TRAO ĐỔI Ý TƯỞNG CÙNG EKIP`})})]})]})}),(0,a.jsxs)(`div`,{className:`contact-shop-content`,children:[(0,a.jsxs)(`div`,{className:`contact-header-section`,children:[(0,a.jsx)(`h1`,{className:`contact-page-title`,children:`CHỤP ẢNH & QUAY PHIM`}),(0,a.jsx)(`p`,{className:`contact-page-subtitle`,children:`Khám phá 3 tài liệu trong mỗi gói: Album ảnh mẫu, Bảng giá chi tiết và Master text nghệ thuật.`})]}),(0,a.jsx)(`div`,{className:`contact-glass-folders-grid`,children:P.map((e,t)=>{let n=[{name:`1. Ảnh mẫu`,meta:`Xem ảnh`,image:e.image},{name:`2. Bảng Giá & Chi Tiết`,meta:e.priceLine,art:e.art},{name:`3. Master Editorial Story`,meta:`Nội dung định hướng`}];return(0,a.jsxs)(`div`,{className:`contact-glass-folder-wrapper`,children:[(0,a.jsx)(`div`,{className:`contact-folder-desktop-view`,children:(0,a.jsx)(O,{label:e.title,meta:e.priceLine,tone:u,art:e.art,files:n,action:`none`,onFileSelect:(t,n)=>d(e,n),width:310,appear:!0,appearDelay:t*60})}),(0,a.jsx)(`div`,{className:`contact-folder-mobile-view`,children:(0,a.jsx)(O,{label:e.title,meta:e.priceLine,tone:u,art:e.art,files:n,action:`none`,onFileSelect:(t,n)=>d(e,n),width:280,appear:!1})}),(0,a.jsxs)(`button`,{type:`button`,className:`contact-folder-quick-btn`,onClick:()=>o({type:`pricing`,product:e}),children:[(0,a.jsx)(`span`,{className:`contact-folder-quick-title`,children:`Bảng giá`}),(0,a.jsx)(`span`,{className:`contact-folder-price-tag`,style:{whiteSpace:`pre-line`,textAlign:`right`,lineHeight:1.35},children:e.priceLine})]})]},e.id)})}),(0,a.jsxs)(`section`,{className:`contact-terms`,"aria-labelledby":`contact-terms-title`,children:[(0,a.jsx)(`h2`,{className:`contact-terms-title`,id:`contact-terms-title`,children:`TERMS OF SERVICE`}),(0,a.jsx)(`ol`,{className:`contact-terms-list`,children:F.map(e=>(0,a.jsxs)(`li`,{className:`contact-terms-section`,children:[(0,a.jsx)(`h3`,{children:e.title}),(0,a.jsx)(`ul`,{children:e.items.map(e=>(0,a.jsx)(`li`,{children:e},e))})]},e.title))})]})]})]})};export{I as default};