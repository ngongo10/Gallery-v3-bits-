import{a as e,o as t,s as n}from"./index-CguPmtBQ.js";var r=n(t(),1),i=e(),a=typeof window>`u`?r.useEffect:r.useLayoutEffect,o={dark:{"--gn-frame":`rgba(38, 35, 46, 0.66)`,"--gn-frame-edge":`rgba(255, 255, 255, 0.08)`,"--gn-frame-highlight":`rgba(255, 255, 255, 0.07)`,"--gn-frame-shadow":`0 22px 44px -20px rgba(0, 0, 0, 0.8), 0 6px 16px -8px rgba(0, 0, 0, 0.5)`,"--gn-ink":`#f4f4f5`,"--gn-muted":`rgba(244, 244, 245, 0.62)`},light:{"--gn-frame":`rgba(240, 240, 243, 0.8)`,"--gn-frame-edge":`rgba(24, 24, 27, 0.07)`,"--gn-frame-highlight":`rgba(255, 255, 255, 0.95)`,"--gn-frame-shadow":`0 22px 44px -22px rgba(24, 24, 27, 0.3), 0 6px 16px -10px rgba(24, 24, 27, 0.16)`,"--gn-ink":`#27272a`,"--gn-muted":`rgba(39, 39, 42, 0.62)`}},s={dark:{color:`#f4f4f5`,hover:`rgba(255, 255, 255, 0.08)`,shadow:.4},light:{color:`#27272a`,hover:`rgba(24, 24, 27, 0.06)`,shadow:.2}},c={sm:`gooey-nav--sm`,md:`gooey-nav--md`,lg:`gooey-nav--lg`},l=[{label:`Home`,href:`#`},{label:`Work`,href:`#`},{label:`About`,href:`#`},{label:`Contact`,href:`#`}],u=32,d=4,f=72,p=`#version 300 es
in vec2 aPosition;
void main() {
  gl_Position = vec4(aPosition, 0.0, 1.0);
}
`,m=`#version 300 es
precision highp float;

uniform vec2 uSize;
uniform float uRatio;
uniform vec4 uPills[${d}];
uniform vec4 uHover;
uniform vec4 uDrops[${u}];
uniform vec2 uTails[${u}];
uniform vec3 uTints[${u}];
uniform int uCount;
uniform float uSmooth;
uniform vec3 uPill;
uniform vec4 uHoverColor;
uniform float uShadow;

out vec4 outColor;

float sdPill(vec2 p, vec4 box) {
  vec2 extent = max(box.zw, vec2(0.0));
  float r = min(extent.x, extent.y);
  vec2 q = abs(p - box.xy) - extent + r;
  return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

float sdCapsule(vec2 p, vec2 a, vec2 b, float r) {
  vec2 pa = p - a;
  vec2 ba = b - a;
  float h = clamp(dot(pa, ba) / max(dot(ba, ba), 0.0001), 0.0, 1.0);
  return length(pa - ba * h) - r;
}

vec4 blend(vec4 a, vec4 b, float k) {
  float h = clamp(0.5 + 0.5 * (b.w - a.w) / k, 0.0, 1.0);
  return vec4(mix(b.rgb, a.rgb, h), mix(b.w, a.w, h) - k * h * (1.0 - h));
}

vec4 field(vec2 p) {
  vec4 shape = vec4(uPill, 1e5);
  for (int i = 0; i < ${d}; i++) {
    vec4 pill = uPills[i];
    if (pill.z <= 0.0) continue;
    shape = blend(shape, vec4(uPill, sdPill(p, pill)), uSmooth);
  }
  for (int i = 0; i < ${u}; i++) {
    if (i >= uCount) break;
    vec4 drop = uDrops[i];
    if (drop.z <= 0.0) continue;
    float d = sdCapsule(p, drop.xy, drop.xy - uTails[i], drop.z);
    if (d > shape.w + uSmooth) continue;
    shape = blend(shape, vec4(uTints[i], d), uSmooth);
  }
  return shape;
}

void main() {
  vec2 p = vec2(gl_FragCoord.x, uSize.y * uRatio - gl_FragCoord.y) / uRatio;
  vec4 shape = field(p);
  float d = shape.w;
  float aa = max(fwidth(d), 0.35);
  float body = clamp(0.5 - d / aa, 0.0, 1.0);

  vec2 grad = vec2(dFdx(d), -dFdy(d));
  vec2 n = length(grad) > 0.0001 ? normalize(grad) : vec2(0.0, 1.0);
  float rim = (1.0 - smoothstep(0.0, 1.6, -d)) * max(0.0, -n.y) * 0.3;
  vec3 fill = mix(shape.rgb, vec3(1.0), rim) * (1.0 - 0.06 * max(0.0, n.y) * (1.0 - smoothstep(0.0, 6.0, -d)));

  float lifted = field(p - vec2(0.0, 3.0)).w;
  float shadow = (1.0 - smoothstep(-3.0, 9.0, lifted)) * uShadow * (1.0 - body);

  float hover = clamp(0.5 - sdPill(p, uHover) / aa, 0.0, 1.0) * uHoverColor.a;

  vec4 color = vec4(0.0, 0.0, 0.0, shadow);
  color = vec4(uHoverColor.rgb * hover, hover) + color * (1.0 - hover);
  color = vec4(fill * body, body) + color * (1.0 - body);
  outColor = color;
}
`,h=e=>{let t=/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(e).trim());if(t){let e=t[1].length===3?t[1].replace(/./g,e=>e+e):t[1];return[0,2,4].map(t=>parseInt(e.slice(t,t+2),16)/255).concat(1)}let n=/rgba?\(([^)]+)\)/i.exec(String(e));if(n){let e=n[1].split(`,`).map(e=>parseFloat(e));return[e[0]/255,e[1]/255,e[2]/255,e[3]??1]}return[1,1,1,1]},g=e=>.2126*e[0]+.7152*e[1]+.0722*e[2]>.55?`#18161d`:`#ffffff`,_=e=>Math.min(1,Math.max(0,e)),v=e=>{let t=_(e);return t<.5?4*t*t*t:1-(-2*t+2)**3/2},y=(e,t,n,r,i)=>{let a=1-i;return a*a*a*e+3*a*a*i*t+3*a*i*i*n+i*i*i*r},b=(e,t,n,r)=>{if(n<=.5||r<=.5)return``;let i=Math.min(n,r)/2;return`M${e+i},${t}H${e+n-i}A${i},${i} 0 0 1 ${e+n},${t+i}V${t+r-i}A${i},${i} 0 0 1 ${e+n-i},${t+r}H${e+i}A${i},${i} 0 0 1 ${e},${t+r-i}V${t+i}A${i},${i} 0 0 1 ${e+i},${t}Z`},x=(e,t,n)=>{let r=e.createShader(t);return e.shaderSource(r,n),e.compileShader(r),r},S=[`uSize`,`uRatio`,`uPills`,`uHover`,`uDrops`,`uTails`,`uTints`,`uCount`,`uSmooth`,`uPill`,`uHoverColor`,`uShadow`],C=e=>{let t=e.createProgram();if(e.attachShader(t,x(e,e.VERTEX_SHADER,p)),e.attachShader(t,x(e,e.FRAGMENT_SHADER,m)),e.linkProgram(t),!e.getProgramParameter(t,e.LINK_STATUS))return e.deleteProgram(t),null;let n=Object.fromEntries(S.map(n=>[n,e.getUniformLocation(t,n)])),r=e.createBuffer();return e.bindBuffer(e.ARRAY_BUFFER,r),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),e.STATIC_DRAW),{program:t,uniforms:n,buffer:r,position:e.getAttribLocation(t,`aPosition`)}},w=({items:e=l,initialActiveIndex:t=0,activeIndex:n,onChange:p,theme:m=`dark`,color:x,activeTextColor:S,colors:w=[],size:T=`md`,frame:E=!0,animationTime:D=600,particleCount:O=15,timeVariance:k=300,spread:A=56,gooeyness:j=.5,wobble:M=.5,hoverEffect:N=!0,className:P=``,style:F})=>{let[I,L]=(0,r.useState)(t),R=Math.min(Math.max(0,n??I),Math.max(0,e.length-1)),z=(0,r.useRef)(null),B=(0,r.useRef)(null),V=(0,r.useRef)(null),H=(0,r.useRef)(null),U=(0,r.useRef)(null),W=(0,r.useRef)(null),G=(0,r.useRef)(R);G.current=R;let K=m===`light`?`light`:`dark`,q=x||s[K].color,J=h(q),Y={animationTime:D,particleCount:O,timeVariance:k,spread:A,gooeyness:j,wobble:M,hoverEffect:N,pillRgb:J,tints:w.map(h),hoverRgb:h(s[K].hover),shadow:s[K].shadow},X=(0,r.useRef)(Y);X.current=Y;let Z=t=>{t!==R&&(n===void 0&&L(t),p?.(t,e[t]))};a(()=>{let e=z.current,t=B.current,n=V.current,r=H.current,i=U.current;if(!e||!t||!n||!r||!i)return;let a=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches,o=t.getContext(`webgl2`,{alpha:!0,premultipliedAlpha:!0,antialias:!1}),s=o?C(o):null;i.style.display=s?`none`:`block`,t.style.display=s?`block`:`none`;let c={width:0,height:0},l=[],p=-1,m=new Map,h=[],g={x:0,y:0,w:0,h:0,alpha:0,index:-1},x=new Float32Array(16),S=new Float32Array(128),w=new Float32Array(64),T=new Float32Array(96),E=0,D=0,O=!1,k=()=>{let r=e.getBoundingClientRect(),i=Math.min(window.devicePixelRatio||1,2);c.width=r.width,c.height=r.height;let a=r.width+144,o=r.height+144;Object.assign(t.style,{left:`-72px`,top:`-72px`,width:`${a}px`,height:`${o}px`});let s=Math.max(1,Math.round(a*i)),u=Math.max(1,Math.round(o*i));(t.width!==s||t.height!==u)&&(t.width=s,t.height=u),l=Array.from(n.children).map(e=>{let t=e.getBoundingClientRect();return{x:t.left-r.left,y:t.top-r.top,w:t.width,h:t.height}})},A=(e,t,n)=>{let r=(r,i)=>{let a=1e5,o=e=>{let t=_(.5+.5*(e-a)/n);a=e+(a-e)*t-n*t*(1-t)};for(let t of e){let e=Math.min(t.hw,t.hh),n=Math.abs(r-t.cx)-t.hw+e,a=Math.abs(i-t.cy)-t.hh+e;o(Math.hypot(Math.max(n,0),Math.max(a,0))+Math.min(Math.max(n,a),0)-e)}for(let e of t){let t=r-e.x,s=i-e.y,c=-e.tx,l=-e.ty,u=c*c+l*l,d=u>1e-4?_((t*c+s*l)/u):0,f=Math.hypot(t-c*d,s-l*d)-e.r;f>a+n||o(f)}return a},i=[];for(let e=0;e<c.height;e+=1){let t=e+.5,n=r(0,t),a=n<0?0:null;for(let o=2;o<=c.width+2;o+=2){let s=r(Math.min(o,c.width),t);if(n<0!=s<0){let t=o-2+2*n/(n-s);s<0?a=t:a!==null&&(i.push(`M${a.toFixed(1)},${e}H${t.toFixed(1)}V${e+1}H${a.toFixed(1)}Z`),a=null)}n=s}a!==null&&i.push(`M${a.toFixed(1)},${e}H${c.width}V${e+1}H${a.toFixed(1)}Z`)}return i.join(``)},j=e=>(m.has(e)||m.set(e,{mass:0,scale:0,velocity:0,outgoing:0}),m.get(e)),M=(e,t)=>{let n=l[e];if(!n||t<=.002)return null;let r=n.h*Math.min(1.08,.42+.58*Math.sqrt(Math.max(0,t))),i=Math.max(r,n.w*Math.max(0,t)**.75);return{x:n.x+n.w/2-i/2,y:n.y+n.h/2-r/2,w:i,h:r}},N=(e,t,n,r)=>{let i=X.current,a=l[t];if(!a)return;let o=Math.max(0,i.spread),s=a.x+a.w/2+(Math.random()-.5)*a.w*.45,c=a.y+a.h/2+(Math.random()-.5)*a.h*.2,u=Math.max(.15,i.animationTime/1e3),d=(Math.random()-.5)*(Math.max(0,i.timeVariance)/1e3),f=Math.max(.15,u*(.62+Math.random()*.32)+d*.6),p=Math.random()*Math.PI*2,m=Math.random()*Math.PI*2,h=o*(.7+Math.random()*.6),g=o*(.55+Math.random()*.55),_=Math.min(f/3,.12);e.index=t,e.start=n,e.duration=f,e.path=[e.x,e.y,r?e.x+Math.cos(p)*h*1.6:e.x+e.vx*_,r?e.y+Math.sin(p)*h*1.6:e.y+e.vy*_,s+Math.cos(m)*g*1.5,c+Math.sin(m)*g*1.5,s,c]},P=(e,t,n)=>{let r=X.current,i=m.get(e),a=l[e];if(!i||!a||!l[t])return;let o=i.mass-i.outgoing;if(o<=.002)return;let s=u-h.length,c=Math.min(s,Math.max(1,Math.round(Math.max(1,r.particleCount)*o)));if(c<=0)return;let d=Math.max(.15,r.animationTime/1e3)*.16;for(let s=0;s<c;s++){let s=o/c;i.outgoing+=s,h.push({x:a.x+a.w/2+(Math.random()-.5)*a.w*.6,y:a.y+a.h/2+(Math.random()-.5)*a.h*.3,vx:0,vy:0,mass:s,size:.8+Math.random()*.4,given:0,source:e,index:t,leave:n+Math.random()*d*1e3,emerged:0,absorbed:0,state:`waiting`,tint:r.tints.length?r.tints[Math.floor(Math.random()*r.tints.length)]:null})}},F=()=>{let e=X.current,n=l[p]?.h??l[0]?.h??36,a=n*(.18+.5*_(e.gooeyness)),v=[],y=[];for(let[e,t]of m){let n=M(e,t.scale);n&&v.push({cx:n.x+n.w/2,cy:n.y+n.h/2,hw:n.w/2,hh:n.h/2})}for(let e of h){if(e.state===`waiting`)continue;let t=.26*n*e.size*Math.min(e.emerged,1-e.absorbed);if(t<=.05)continue;let r=Math.hypot(e.vx,e.vy),i=Math.min(t*1.1,r*.018);y.push({x:e.x,y:e.y,r:t,tx:r>.01?e.vx/r*i:0,ty:r>.01?e.vy/r*i:0,tint:e.tint})}if(v.length===1&&!y.length){let e=v[0];r.style.clipPath=`path('${b(e.cx-e.hw,e.cy-e.hh,e.hw*2,e.hh*2)}')`}else r.style.clipPath=`path('${A(v,y,a)||`M0,0Z`}')`;if(r.style.visibility=`visible`,!s||!o){let e=M(p,1);e&&(i.style.transform=`translate(${e.x.toFixed(2)}px, ${e.y.toFixed(2)}px)`,i.style.width=`${e.w}px`,i.style.height=`${e.h}px`),i.style.opacity=e?`1`:`0`;return}let C=0;for(let e of v){if(C>=d)break;x[C*4]=e.cx+f,x[C*4+1]=e.cy+f,x[C*4+2]=e.hw,x[C*4+3]=e.hh,C+=1}x.fill(0,C*4);let E=0;for(let t of y){if(E>=u)break;S[E*4]=t.x+f,S[E*4+1]=t.y+f,S[E*4+2]=t.r,S[E*4+3]=0,w[E*2]=t.tx,w[E*2+1]=t.ty;let n=t.tint||e.pillRgb;T[E*3]=n[0],T[E*3+1]=n[1],T[E*3+2]=n[2],E+=1}let{program:D,uniforms:O,buffer:k,position:j}=s;o.viewport(0,0,t.width,t.height),o.clearColor(0,0,0,0),o.clear(o.COLOR_BUFFER_BIT),o.useProgram(D),o.bindBuffer(o.ARRAY_BUFFER,k),o.enableVertexAttribArray(j),o.vertexAttribPointer(j,2,o.FLOAT,!1,0,0),o.uniform2f(O.uSize,c.width+144,c.height+144),o.uniform1f(O.uRatio,t.width/Math.max(1,c.width+144)),o.uniform4fv(O.uPills,x),o.uniform4f(O.uHover,g.x+f,g.y+f,g.w/2,g.h/2),o.uniform4fv(O.uDrops,S),o.uniform2fv(O.uTails,w),o.uniform3fv(O.uTints,T),o.uniform1i(O.uCount,E),o.uniform1f(O.uSmooth,a),o.uniform3f(O.uPill,e.pillRgb[0],e.pillRgb[1],e.pillRgb[2]),o.uniform4f(O.uHoverColor,e.hoverRgb[0],e.hoverRgb[1],e.hoverRgb[2],e.hoverRgb[3]*g.alpha),o.uniform1f(O.uShadow,e.shadow),o.drawArrays(o.TRIANGLE_STRIP,0,4)},I=e=>{E=0;let t=X.current,n=Math.min(.05,(e-D)/1e3||0);D=e;let r=.09;for(let t=h.length-1;t>=0;t--){let i=h[t];if(i.state===`waiting`){if(e<i.leave)continue;i.state=`flying`,N(i,i.index,e,!0)}if(i.state===`flying`){i.emerged=Math.min(1,i.emerged+n/r);let t=m.get(i.source);if(t&&i.given<i.mass){let e=Math.min(i.mass*(n/r),i.mass-i.given);t.mass=Math.max(0,t.mass-e),t.outgoing=Math.max(0,t.outgoing-e),i.given+=e}let a=_((e-i.start)/1e3/i.duration),o=v(a),[s,c,l,u,d,f,p,h]=i.path,g=y(s,l,d,p,o),b=y(c,u,f,h,o);n>0&&(i.vx=(g-i.x)/n,i.vy=(b-i.y)/n),i.x=g,i.y=b,a>=1&&(i.state=`absorbing`)}if(i.state===`absorbing`){let e=Math.min(1-i.absorbed,n/.12);i.absorbed+=e,i.vx*=.8,i.vy*=.8;let r=j(i.index);r.mass=Math.min(1,r.mass+i.mass*e),i.absorbed>=1&&h.splice(t,1)}}let i=a?1:1-.72*_(t.wobble),o=Math.max(1,Math.ceil(n/(1/240))),s=n/o;for(let[e,t]of m){for(let e=0;e<o;e++)t.velocity+=(676*(t.mass-t.scale)-2*i*26*t.velocity)*s,t.scale+=t.velocity*s;e!==p&&t.mass<=.002&&t.outgoing<=.002&&Math.abs(t.scale)<.004&&m.delete(e)}if(g.index>=0&&l[g.index]){let e=l[g.index],t=1-Math.exp(-n/.06);g.x+=(e.x+e.w/2-g.x)*t,g.y+=(e.y+e.h/2-g.y)*t,g.w+=(e.w-g.w)*t,g.h+=(e.h-g.h)*t}let c=t.hoverEffect&&g.index>=0&&g.index!==p?1:0;g.alpha+=(c-g.alpha)*(1-Math.exp(-n/.08)),F();let u=m.get(p),d=h.length===0&&m.size===1&&u&&Math.abs(u.mass-u.scale)<8e-4&&Math.abs(u.velocity)<.004,f=l[g.index],b=Math.abs(c-g.alpha)>.003||f&&Math.abs(f.x+f.w/2-g.x)+Math.abs(f.w-g.w)>.1;!d||b?E=requestAnimationFrame(I):(u.mass=1,u.scale=1,u.velocity=0,g.alpha=c,F())},L=()=>{E||O||(D=performance.now(),E=requestAnimationFrame(I))},R=e=>{m.clear(),h.length=0,p=e;let t=j(e);t.mass=1,t.scale=1,t.velocity=0,F()},K=(e,t)=>{if(e===p)return;if(!l[e]||!t||a||p<0){R(e);return}let n=performance.now();p=e,j(e);for(let t of h)t.index=e,t.state===`flying`&&N(t,e,n,!1),t.state===`absorbing`&&(t.state=`flying`,t.mass*=1-t.absorbed,t.absorbed=0,N(t,e,n,!1));for(let t of[...m.keys()])t!==e&&P(t,e,n);L()},q=e=>{let t=e.target.closest(`[data-gooey-index]`);if(!t||!n.contains(t))return;let r=Number(t.dataset.gooeyIndex),i=l[r];i&&(g.alpha<.01&&(g.x=i.x+i.w/2,g.y=i.y+i.h/2,g.w=i.w,g.h=i.h),g.index=r,L())},J=()=>{g.index=-1,L()},Y=new ResizeObserver(()=>{k(),h.length?F():R(p<0?G.current:p)});return Y.observe(e),Y.observe(n),n.addEventListener(`pointerover`,q),n.addEventListener(`pointerleave`,J),k(),R(G.current),document.fonts?.ready.then(()=>{O||(k(),h.length||R(p))}),W.current={go:e=>K(e,!0),refresh:()=>{F(),L()}},()=>{O=!0,cancelAnimationFrame(E),Y.disconnect(),n.removeEventListener(`pointerover`,q),n.removeEventListener(`pointerleave`,J),o&&s&&(o.deleteBuffer(s.buffer),o.deleteProgram(s.program)),W.current=null}},[e.length]),(0,r.useEffect)(()=>{W.current?.go(R)},[R]),(0,r.useEffect)(()=>{W.current?.refresh()},[q,K,j,T,E]);let Q=S||g(J),$=t=>e.map((e,n)=>{let r=(0,i.jsxs)(i.Fragment,{children:[e.icon&&(0,i.jsx)(`span`,{className:`gooey-nav__icon`,children:e.icon}),e.label&&(0,i.jsx)(`span`,{className:`gooey-nav__label`,children:e.label})]});if(!t)return(0,i.jsx)(`li`,{className:`gooey-nav__item`,children:(0,i.jsx)(`span`,{className:`gooey-nav__link`,children:r})},n);let a={className:`gooey-nav__link`,"aria-current":n===R?`page`:void 0,onClick:t=>{(!e.href||e.href===`#`)&&t.preventDefault(),Z(n),e.onClick?.()}};return(0,i.jsx)(`li`,{className:`gooey-nav__item`,"data-gooey-index":n,"data-active":n===R?``:void 0,children:e.href?(0,i.jsx)(`a`,{href:e.href,...a,children:r}):(0,i.jsx)(`button`,{type:`button`,...a,children:r})},n)});return(0,i.jsxs)(`nav`,{className:`gooey-nav ${c[T]??c.md}${E?` gooey-nav--framed`:``} ${P}`.trim(),style:{...o[K],"--gn-pill":q,"--gn-active-ink":Q,...F},children:[E&&(0,i.jsx)(`span`,{className:`gooey-nav__rim`}),(0,i.jsxs)(`div`,{ref:z,className:`gooey-nav__stage`,children:[(0,i.jsx)(`canvas`,{ref:B,className:`gooey-nav__canvas`,"aria-hidden":`true`}),(0,i.jsx)(`span`,{ref:U,className:`gooey-nav__fallback`,"aria-hidden":`true`}),(0,i.jsx)(`ul`,{ref:V,className:`gooey-nav__list`,children:$(!0)}),(0,i.jsx)(`ul`,{ref:H,className:`gooey-nav__list gooey-nav__list--active`,"aria-hidden":`true`,children:$(!1)})]})]})};export{w as default};